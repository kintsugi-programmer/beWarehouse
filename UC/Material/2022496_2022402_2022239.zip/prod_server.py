from flask import Flask, request, jsonify
import os
import uuid
import json

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
DATA_LOG_FOLDER = 'data_logs'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(DATA_LOG_FOLDER, exist_ok=True)

def get_unique_filename(directory, filename):
    """Ensures unique filenames to avoid overwriting existing files."""
    name, ext = os.path.splitext(filename)
    counter = 1
    new_filename = filename

    while os.path.exists(os.path.join(directory, new_filename)):
        new_filename = f"{name}_{counter}{ext}"
        counter += 1
    
    return new_filename

@app.route('/', methods=['GET'])
def home():
    return "Server is running!"

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handles file and sensor data uploads while maintaining correlation."""
    
    unique_id = str(uuid.uuid4())  # Generate a unique identifier for each entry

    # ✅ Handling JSON Data
    if request.is_json:
        data = request.get_json()
        print("Received JSON Data:", data)

        # Add unique ID for tracking
        data["id"] = unique_id
        
        # Save structured data to a JSON file
        data_log_path = os.path.join(DATA_LOG_FOLDER, f"{unique_id}.json")
        with open(data_log_path, "w") as f:
            json.dump(data, f, indent=4)

    # ✅ Handling File Uploads (Images)
    if "filename" in request.files:
        uploaded_file = request.files["filename"]
        if uploaded_file.filename != "":
            # Save the image using the same unique identifier
            ext = os.path.splitext(uploaded_file.filename)[-1]
            image_filename = f"{unique_id}{ext}"
            save_path = os.path.join(UPLOAD_FOLDER, image_filename)
            uploaded_file.save(save_path)

            return jsonify({
                "message": "File and data uploaded successfully!",
                "id": unique_id,
                "filename": image_filename
            }), 200
    
    return jsonify({"message": "Data received without a file", "id": unique_id}), 200


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
