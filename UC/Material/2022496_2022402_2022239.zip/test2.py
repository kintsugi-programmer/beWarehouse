from flask import Flask, request, jsonify
import os
import threading
import time

app = Flask(__name__)

UPLOAD_FOLDER = 'dataset'
CATEGORIES = {"l": "left", "s": "straight", "r": "right"}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Ensure category folders exist
for folder in CATEGORIES.values():
    os.makedirs(os.path.join(UPLOAD_FOLDER, folder), exist_ok=True)

# Global variable to store last classification
last_classification = None
lock = threading.Lock()

def get_unique_filename(directory, filename):
    """Generate a unique filename if a file already exists."""
    name, ext = os.path.splitext(filename)
    counter = 1
    new_filename = filename
    
    while os.path.exists(os.path.join(directory, new_filename)):
        new_filename = f"{name}_{counter}{ext}"
        counter += 1
    
    return new_filename

def classify_image(file_path):
    """Prompt the user to classify the image manually and return the category."""
    global last_classification
    print(f"New image received: {file_path}")
    
    # Prompt user for classification
    user_input = input("Classify image (l: left, s: straight, r: right) [Press Enter to use last classification]: ").strip().lower()
    
    # If user provides a valid input, update classification
    if user_input in CATEGORIES:
        last_classification = CATEGORIES[user_input]
    
    # If no input, use the last classification
    if last_classification:
        target_folder = os.path.join(UPLOAD_FOLDER, last_classification)
        new_file_path = os.path.join(target_folder, os.path.basename(file_path))
        os.rename(file_path, new_file_path)
        print(f"Image classified as {last_classification.upper()} and moved to {new_file_path}")
    else:
        print("No classification provided, and no previous classification available. Image will not be moved.")

@app.route('/', methods=['GET'])
def home():
    return "Server is running!"

@app.route('/upload', methods=['POST'])
def upload_file():
    global last_classification

    print("Request form:", request.form)
    print("Request files:", request.files.keys())

    if 'filename' in request.files:
        uploaded_file = request.files['filename']
        if uploaded_file.filename == '':
            return "No file selected", 400

        unique_filename = get_unique_filename(UPLOAD_FOLDER, uploaded_file.filename)
        save_path = os.path.join(UPLOAD_FOLDER, unique_filename)
        uploaded_file.save(save_path)

        # Start classification in a separate thread
        threading.Thread(target=classify_image, args=(save_path,)).start()
        
        return jsonify({"message": "File uploaded and waiting for classification.", "filename": unique_filename}), 200

    return "No file received", 400

@app.route('/upload2', methods=['POST'])
def upload2():
    """Handle JSON sensor data and images"""
    global last_classification

    # ✅ Handling JSON Data
    if request.is_json:
        data = request.get_json()
        print("Received JSON Data:", data)

        # Extract relevant fields
        distance = data.get("distance", "N/A")
        light = data.get("light", "N/A")
        latitude = data.get("latitude", "N/A")
        longitude = data.get("longitude", "N/A")
        ax = data.get("ax", "N/A")
        ay = data.get("ay", "N/A")
        az = data.get("az", "N/A")
        gx = data.get("gx", "N/A")
        gy = data.get("gy", "N/A")
        gz = data.get("gz", "N/A")

        # Save structured data to a log file
        os.makedirs("data_logs", exist_ok=True)
        with open("data_logs/sensor_data.txt", "a") as f:
            f.write(f"Distance: {distance}, Light: {light}, Lat: {latitude}, Long: {longitude}, "
                    f"AX: {ax}, AY: {ay}, AZ: {az}, GX: {gx}, GY: {gy}, GZ: {gz}\n")

    # ✅ Handling File Uploads (Images)
    if "filename" in request.files:
        uploaded_file = request.files["filename"]
        if uploaded_file.filename != "":
            unique_filename = get_unique_filename(UPLOAD_FOLDER, uploaded_file.filename)
            save_path = os.path.join(UPLOAD_FOLDER, unique_filename)
            uploaded_file.save(save_path)

            # Start classification in a separate thread
            threading.Thread(target=classify_image, args=(save_path,)).start()

            return jsonify({
                "message": "File and data uploaded successfully! Waiting for classification.",
                "filename": uploaded_file.filename
            }), 200

    return jsonify({"message": "Data received without a file"}), 200

def predict():
    """Placeholder function for future model prediction."""
    prediction = ''
    return prediction

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
